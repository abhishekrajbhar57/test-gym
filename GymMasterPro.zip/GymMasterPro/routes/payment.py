from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required, current_user
from models import Gym, Member, Payment
from forms import PaymentForm
from app import db
from utils import send_payment_notification
from datetime import datetime

payment_bp = Blueprint('payment', __name__)

def get_current_gym():
    """Helper function to get the current gym for the logged-in manager"""
    return Gym.query.filter_by(user_id=current_user.id).first()

@payment_bp.route('/list')
@login_required
def list_payments():
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    # Get all payments for this gym
    payments = Payment.query.filter_by(gym_id=gym.id).order_by(Payment.date.desc()).all()
    
    # Get member names
    members_dict = {}
    for payment in payments:
        member = Member.query.get(payment.member_id)
        if member:
            members_dict[payment.member_id] = member.full_name
    
    return render_template('gym/payments.html', payments=payments, gym=gym, members=members_dict)

@payment_bp.route('/add', methods=['GET', 'POST'])
@login_required
def add_payment():
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    # Get all members for dropdown
    members = Member.query.filter_by(gym_id=gym.id).all()
    form = PaymentForm()
    form.member_id.choices = [(m.id, m.full_name) for m in members]
    
    if form.validate_on_submit():
        # Create new payment
        payment = Payment(
            member_id=form.member_id.data,
            amount=str(form.amount.data),  # Convert to string as per requirements
            date=form.date.data,
            payment_mode=form.payment_mode.data,
            gym_id=gym.id
        )
        
        db.session.add(payment)
        db.session.commit()
        
        # Send email notification
        send_payment_notification(payment)
        
        flash('Payment recorded successfully!', 'success')
        flash('भुगतान सफलतापूर्वक दर्ज किया गया!', 'success')
        return redirect(url_for('payment.list_payments'))
    
    return render_template('gym/payment_form.html', form=form, gym=gym)

@payment_bp.route('/delete/<int:payment_id>')
@login_required
def delete_payment(payment_id):
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    payment = Payment.query.get_or_404(payment_id)
    
    # Ensure payment belongs to this gym
    if payment.gym_id != gym.id:
        flash('You do not have permission to delete this payment.', 'danger')
        return redirect(url_for('payment.list_payments'))
    
    db.session.delete(payment)
    db.session.commit()
    
    flash('Payment deleted successfully!', 'success')
    flash('भुगतान सफलतापूर्वक हटा दिया गया!', 'success')
    return redirect(url_for('payment.list_payments'))

@payment_bp.route('/get_invoice_data/<int:payment_id>')
@login_required
def get_invoice_data(payment_id):
    gym = get_current_gym()
    if not gym:
        return jsonify({'success': False, 'message': 'No gym found'})
    
    payment = Payment.query.get_or_404(payment_id)
    
    # Ensure payment belongs to this gym
    if payment.gym_id != gym.id:
        return jsonify({'success': False, 'message': 'Access denied'})
    
    member = Member.query.get(payment.member_id)
    
    invoice_data = {
        'gym_name': gym.name,
        'member_name': member.full_name,
        'amount': payment.amount,
        'date': payment.date.strftime('%Y-%m-%d'),
        'payment_id': payment.id,
        'payment_mode': payment.payment_mode
    }
    
    return jsonify({'success': True, 'data': invoice_data})
