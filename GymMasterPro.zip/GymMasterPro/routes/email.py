from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required, current_user
from models import Gym, EmailSettings
from app import db
import json

email_bp = Blueprint('email', __name__)

def get_current_gym():
    """Helper function to get the current gym for the logged-in manager"""
    return Gym.query.filter_by(user_id=current_user.id).first()

@email_bp.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    email_settings = EmailSettings.query.filter_by(gym_id=gym.id).first()
    
    if not email_settings:
        from utils import create_default_email_settings
        email_settings = create_default_email_settings(gym.id)
    
    if request.method == 'POST':
        enabled = 'enabled' in request.form
        
        membership_expiry_subject = request.form.get('membership_expiry_subject')
        membership_expiry_template_en = request.form.get('membership_expiry_template_en')
        membership_expiry_template_hi = request.form.get('membership_expiry_template_hi')
        
        payment_success_subject = request.form.get('payment_success_subject')
        payment_success_template_en = request.form.get('payment_success_template_en')
        payment_success_template_hi = request.form.get('payment_success_template_hi')
        
        attendance_marked_subject = request.form.get('attendance_marked_subject')
        attendance_marked_template_en = request.form.get('attendance_marked_template_en')
        attendance_marked_template_hi = request.form.get('attendance_marked_template_hi')
        
        email_settings.enabled = enabled
        
        email_settings.membership_expiry_subject = membership_expiry_subject
        membership_expiry_template = {
            'en': membership_expiry_template_en,
            'hi': membership_expiry_template_hi
        }
        email_settings.membership_expiry_template = json.dumps(membership_expiry_template)
        
        email_settings.payment_success_subject = payment_success_subject
        payment_success_template = {
            'en': payment_success_template_en,
            'hi': payment_success_template_hi
        }
        email_settings.payment_success_template = json.dumps(payment_success_template)
        
        email_settings.attendance_marked_subject = attendance_marked_subject
        attendance_marked_template = {
            'en': attendance_marked_template_en,
            'hi': attendance_marked_template_hi
        }
        email_settings.attendance_marked_template = json.dumps(attendance_marked_template)
        
        db.session.commit()
        flash('Email settings updated successfully!', 'success')
        return redirect(url_for('gym.dashboard'))
    
    templates = {
        'membership_expiry': json.loads(email_settings.membership_expiry_template),
        'payment_success': json.loads(email_settings.payment_success_template),
        'attendance_marked': json.loads(email_settings.attendance_marked_template)
    }
    
    return render_template('admin/email_settings.html', 
                          gym=gym, 
                          email_settings=email_settings, 
                          templates=templates)

@email_bp.route('/test', methods=['POST'])
@login_required
def test_email():
    gym = get_current_gym()
    if not gym:
        return jsonify({'success': False, 'message': 'No gym found'})
    
    email = request.json.get('email')
    template_type = request.json.get('template_type')
    
    if not email or not template_type:
        return jsonify({'success': False, 'message': 'Missing parameters'})
    
    email_settings = EmailSettings.query.filter_by(gym_id=gym.id).first()
    
    if not email_settings:
        return jsonify({'success': False, 'message': 'Email settings not found'})
    
    from utils import send_email
    
    if template_type == 'membership_expiry':
        subject = email_settings.membership_expiry_subject
        templates = json.loads(email_settings.membership_expiry_template)
        template = templates.get('en')
        
        content = template.replace('{{member_name}}', 'Test Member')
        content = content.replace('{{expiry_date}}', '2023-12-31')
        content = content.replace('{{gym_name}}', gym.name)
        
    elif template_type == 'payment_success':
        subject = email_settings.payment_success_subject
        templates = json.loads(email_settings.payment_success_template)
        template = templates.get('en')
        
        content = template.replace('{{member_name}}', 'Test Member')
        content = content.replace('{{amount}}', '1000')
        content = content.replace('{{date}}', '2023-11-15')
        content = content.replace('{{gym_name}}', gym.name)
        
    elif template_type == 'attendance_marked':
        subject = email_settings.attendance_marked_subject
        templates = json.loads(email_settings.attendance_marked_template)
        template = templates.get('en')
        
        content = template.replace('{{member_name}}', 'Test Member')
        content = content.replace('{{date}}', '2023-11-15')
        content = content.replace('{{gym_name}}', gym.name)
        
    else:
        return jsonify({'success': False, 'message': 'Invalid template type'})
    
    result = send_email(email, subject, content)
    
    if result:
        return jsonify({'success': True, 'message': 'Test email sent successfully'})
    else:
        return jsonify({'success': False, 'message': 'Failed to send test email'})
