from flask import Blueprint, render_template, request, flash, redirect, url_for, send_file
from flask_login import login_required, current_user
from werkzeug.security import generate_password_hash
from models import User, Gym, Member, EmailSettings
from forms import GymForm, EmailSettingsForm
from utils import export_gym_members
from app import db
import json

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    """Decorator to check if user is admin"""
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'admin':
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@admin_bp.route('/dashboard')
@login_required
@admin_required
def dashboard():
    gym_count = Gym.query.count()
    member_count = Member.query.count()
    return render_template('admin/dashboard.html', gym_count=gym_count, member_count=member_count)

@admin_bp.route('/gyms')
@login_required
@admin_required
def gyms():
    gyms = Gym.query.all()
    return render_template('admin/gyms.html', gyms=gyms)

@admin_bp.route('/add_gym', methods=['GET', 'POST'])
@login_required
@admin_required
def add_gym():
    form = GymForm()
    
    if form.validate_on_submit():
        # Check if username already exists
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash('Username already exists.', 'danger')
            return render_template('admin/gym_form.html', form=form, title='Add New Gym')
            
        # Create gym manager user
        manager = User(
            username=form.username.data,
            password_hash=generate_password_hash(form.password.data),
            email=form.email.data,
            role='gym_manager',
            is_active=True
        )
        
        db.session.add(manager)
        db.session.flush()  # Get the ID without committing
        
        # Create gym
        gym = Gym(
            name=form.name.data,
            user_id=manager.id
        )
        
        db.session.add(gym)
        db.session.commit()
        
        # Create default email settings for the gym
        from utils import create_default_email_settings
        create_default_email_settings(gym.id)
        
        flash('Gym added successfully!', 'success')
        flash('जिम सफलतापूर्वक जोड़ा गया!', 'success')
        return redirect(url_for('admin.gyms'))
        
    return render_template('admin/gym_form.html', form=form, title='Add New Gym')

@admin_bp.route('/edit_gym/<int:gym_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_gym(gym_id):
    gym = Gym.query.get_or_404(gym_id)
    manager = User.query.get(gym.user_id)
    
    form = GymForm(obj=gym)
    form.username.data = manager.username
    form.email.data = manager.email
    
    if form.validate_on_submit():
        # Update gym
        gym.name = form.name.data
        
        # Update manager if username changed
        if form.username.data != manager.username:
            existing_user = User.query.filter_by(username=form.username.data).first()
            if existing_user and existing_user.id != manager.id:
                flash('Username already exists.', 'danger')
                return render_template('admin/gym_form.html', form=form, title='Edit Gym')
            manager.username = form.username.data
            
        # Update manager email
        manager.email = form.email.data
        
        # Update password if provided
        if form.password.data:
            manager.password_hash = generate_password_hash(form.password.data)
            
        db.session.commit()
        flash('Gym updated successfully!', 'success')
        flash('जिम सफलतापूर्वक अपडेट किया गया!', 'success')
        return redirect(url_for('admin.gyms'))
        
    return render_template('admin/gym_form.html', form=form, title='Edit Gym')

@admin_bp.route('/toggle_gym/<int:gym_id>')
@login_required
@admin_required
def toggle_gym(gym_id):
    gym = Gym.query.get_or_404(gym_id)
    manager = User.query.get(gym.user_id)
    
    manager.is_active = not manager.is_active
    db.session.commit()
    
    status = 'activated' if manager.is_active else 'deactivated'
    flash(f'Gym {status} successfully!', 'success')
    return redirect(url_for('admin.gyms'))

@admin_bp.route('/delete_gym/<int:gym_id>')
@login_required
@admin_required
def delete_gym(gym_id):
    gym = Gym.query.get_or_404(gym_id)
    manager = User.query.get(gym.user_id)
    
    db.session.delete(gym)  # Will cascade delete members, attendances, payments
    db.session.delete(manager)
    db.session.commit()
    
    flash('Gym and all associated data deleted successfully!', 'success')
    flash('जिम और सभी संबंधित डेटा सफलतापूर्वक हटा दिया गया!', 'success')
    return redirect(url_for('admin.gyms'))

@admin_bp.route('/export_members/<int:gym_id>')
@login_required
@admin_required
def export_members(gym_id):
    gym = Gym.query.get_or_404(gym_id)
    
    csv_data = export_gym_members(gym_id)
    return send_file(
        csv_data,
        mimetype='text/csv',
        download_name=f'{gym.name}_members.csv',
        as_attachment=True
    )

@admin_bp.route('/email_settings/<int:gym_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def email_settings(gym_id):
    gym = Gym.query.get_or_404(gym_id)
    email_settings = EmailSettings.query.filter_by(gym_id=gym_id).first()
    
    if not email_settings:
        from utils import create_default_email_settings
        email_settings = create_default_email_settings(gym_id)
    
    form = EmailSettingsForm()
    
    # Parse templates for the template
    templates = {
        'membership_expiry': {
            'en': '',
            'hi': ''
        },
        'payment_success': {
            'en': '',
            'hi': ''
        },
        'attendance_marked': {
            'en': '',
            'hi': ''
        }
    }
    
    if request.method == 'GET':
        form.enabled.data = email_settings.enabled
        
        form.membership_expiry_subject.data = email_settings.membership_expiry_subject
        membership_expiry_template = json.loads(email_settings.membership_expiry_template)
        form.membership_expiry_template_en.data = membership_expiry_template.get('en', '')
        form.membership_expiry_template_hi.data = membership_expiry_template.get('hi', '')
        templates['membership_expiry']['en'] = membership_expiry_template.get('en', '')
        templates['membership_expiry']['hi'] = membership_expiry_template.get('hi', '')
        
        form.payment_success_subject.data = email_settings.payment_success_subject
        payment_success_template = json.loads(email_settings.payment_success_template)
        form.payment_success_template_en.data = payment_success_template.get('en', '')
        form.payment_success_template_hi.data = payment_success_template.get('hi', '')
        templates['payment_success']['en'] = payment_success_template.get('en', '')
        templates['payment_success']['hi'] = payment_success_template.get('hi', '')
        
        form.attendance_marked_subject.data = email_settings.attendance_marked_subject
        attendance_marked_template = json.loads(email_settings.attendance_marked_template)
        form.attendance_marked_template_en.data = attendance_marked_template.get('en', '')
        form.attendance_marked_template_hi.data = attendance_marked_template.get('hi', '')
        templates['attendance_marked']['en'] = attendance_marked_template.get('en', '')
        templates['attendance_marked']['hi'] = attendance_marked_template.get('hi', '')
    
    if form.validate_on_submit():
        email_settings.enabled = form.enabled.data
        
        email_settings.membership_expiry_subject = form.membership_expiry_subject.data
        membership_expiry_template = {
            'en': form.membership_expiry_template_en.data,
            'hi': form.membership_expiry_template_hi.data
        }
        email_settings.membership_expiry_template = json.dumps(membership_expiry_template)
        
        email_settings.payment_success_subject = form.payment_success_subject.data
        payment_success_template = {
            'en': form.payment_success_template_en.data,
            'hi': form.payment_success_template_hi.data
        }
        email_settings.payment_success_template = json.dumps(payment_success_template)
        
        email_settings.attendance_marked_subject = form.attendance_marked_subject.data
        attendance_marked_template = {
            'en': form.attendance_marked_template_en.data,
            'hi': form.attendance_marked_template_hi.data
        }
        email_settings.attendance_marked_template = json.dumps(attendance_marked_template)
        
        db.session.commit()
        flash('Email settings updated successfully!', 'success')
        return redirect(url_for('admin.gyms'))
    
    return render_template('admin/email_settings.html', form=form, gym=gym, email_settings=email_settings, templates=templates)
