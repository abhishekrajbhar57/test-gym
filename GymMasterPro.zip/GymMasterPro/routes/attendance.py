from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required, current_user
from datetime import datetime
from models import Gym, Member, Attendance
from forms import AttendanceForm
from app import db, csrf
from utils import send_attendance_notification

attendance_bp = Blueprint('attendance', __name__)

def get_current_gym():
    """Helper function to get the current gym for the logged-in manager"""
    return Gym.query.filter_by(user_id=current_user.id).first()

@attendance_bp.route('/list')
@login_required
def list_attendance():
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    date_str = request.args.get('date', datetime.utcnow().strftime('%Y-%m-%d'))
    try:
        date = datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        date = datetime.utcnow().date()
    
    attendances = Attendance.query.filter_by(gym_id=gym.id, date=date).all()
    
    # Get member names
    members_dict = {}
    for attendance in attendances:
        member = Member.query.get(attendance.member_id)
        if member:
            members_dict[attendance.member_id] = member.full_name
    
    return render_template('gym/attendance.html', 
                          attendances=attendances, 
                          date=date, 
                          gym=gym, 
                          members=members_dict)

@attendance_bp.route('/manual')
@login_required
def manual_attendance():
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    # Get current date
    date = datetime.utcnow().date()
    
    # Get all active members
    members = Member.query.filter_by(gym_id=gym.id).all()
    
    # Get members who already have attendance for today
    today_attendances = Attendance.query.filter_by(gym_id=gym.id, date=date).all()
    marked_members = [attendance.member_id for attendance in today_attendances]
    marked_attendance = [member for member in members if member.id in marked_members]
    
    # Import utility function
    from utils import is_membership_expired
    
    return render_template('gym/manual_attendance.html', 
                          members=members, 
                          date=date, 
                          gym=gym, 
                          marked_attendance=marked_attendance,
                          is_expired=is_membership_expired)

@attendance_bp.route('/mark', methods=['POST'])
@login_required
@csrf.exempt
def mark_attendance():
    gym = get_current_gym()
    if not gym:
        return jsonify({'success': False, 'message': 'No gym found'})
    
    form = AttendanceForm()
    
    if form.validate_on_submit():
        member_id = form.member_id.data
        
        # Verify member belongs to this gym
        member = Member.query.filter_by(id=member_id, gym_id=gym.id).first()
        if not member:
            return jsonify({'success': False, 'message': 'Member not found'})
        
        # Check if attendance already marked for today
        today = datetime.utcnow().date()
        existing = Attendance.query.filter_by(
            member_id=member_id, 
            date=today,
            gym_id=gym.id
        ).first()
        
        if existing:
            return jsonify({
                'success': False, 
                'message': 'Attendance already marked for today',
                'hindi_message': 'आज की उपस्थिति पहले ही चिह्नित कर दी गई है'
            })
        
        # Mark attendance
        attendance = Attendance(
            member_id=member_id,
            date=today,
            gym_id=gym.id,
            method='manual'
        )
        
        db.session.add(attendance)
        db.session.commit()
        
        # Send email notification
        send_attendance_notification(attendance)
        
        return jsonify({
            'success': True, 
            'message': 'Attendance marked successfully',
            'hindi_message': 'उपस्थिति सफलतापूर्वक चिह्नित की गई'
        })
    
    return jsonify({'success': False, 'message': 'Invalid form data'})

@attendance_bp.route('/mark_multiple', methods=['POST'])
@login_required
@csrf.exempt
def mark_multiple_attendance():
    gym = get_current_gym()
    if not gym:
        return jsonify({'success': False, 'message': 'No gym found'})
    
    # Get member IDs from request
    data = request.json
    member_ids = data.get('member_ids', [])
    
    if not member_ids:
        return jsonify({
            'success': False, 
            'message': 'No members selected',
            'hindi_message': 'कोई सदस्य चयनित नहीं'
        })
    
    today = datetime.utcnow().date()
    marked_count = 0
    marked_members = []
    
    for member_id in member_ids:
        try:
            member_id = int(member_id)
            
            # Verify member belongs to this gym
            member = Member.query.filter_by(id=member_id, gym_id=gym.id).first()
            if not member:
                continue
            
            # Check if membership is expired
            from utils import is_membership_expired
            if is_membership_expired(member):
                continue
                
            # Check if attendance already marked for today
            existing = Attendance.query.filter_by(
                member_id=member_id, 
                date=today,
                gym_id=gym.id
            ).first()
            
            if existing:
                continue
            
            # Mark attendance
            attendance = Attendance(
                member_id=member_id,
                date=today,
                gym_id=gym.id,
                method='manual'
            )
            
            db.session.add(attendance)
            marked_count += 1
            marked_members.append(member_id)
            
            # Send email notification
            send_attendance_notification(attendance)
            
        except (ValueError, TypeError):
            continue
    
    if marked_count > 0:
        db.session.commit()
        return jsonify({
            'success': True, 
            'message': f'Attendance marked successfully for {marked_count} members',
            'hindi_message': f'{marked_count} सदस्यों के लिए उपस्थिति सफलतापूर्वक चिह्नित की गई',
            'marked_members': marked_members
        })
    else:
        return jsonify({
            'success': False, 
            'message': 'No new attendance records added. Members may already be marked or have expired memberships',
            'hindi_message': 'कोई नया अटेंडेंस रिकॉर्ड नहीं जोड़ा गया। सदस्यों की उपस्थिति पहले से ही चिह्नित हो सकती है या उनकी सदस्यता समाप्त हो सकती है'
        })

@attendance_bp.route('/scan_qr')
@login_required
def scan_qr():
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
        
    return render_template('gym/qr_scanner.html', gym=gym)

@attendance_bp.route('/process_qr', methods=['POST'])
@login_required
@csrf.exempt
def process_qr():
    gym = get_current_gym()
    if not gym:
        return jsonify({'success': False, 'message': 'No gym found'})
    
    data = request.json.get('qrData')
    
    # QR data should be in format "gym_id:member_id"
    try:
        qr_gym_id, member_id = data.split(':')
        qr_gym_id = int(qr_gym_id)
        member_id = int(member_id)
    except (ValueError, AttributeError):
        return jsonify({
            'success': False, 
            'message': 'Invalid QR code',
            'hindi_message': 'अमान्य QR कोड'
        })
    
    # Verify QR code is for this gym
    if qr_gym_id != gym.id:
        return jsonify({
            'success': False, 
            'message': 'This QR code is for a different gym',
            'hindi_message': 'यह QR कोड किसी अन्य जिम के लिए है'
        })
    
    # Verify member exists in this gym
    member = Member.query.filter_by(id=member_id, gym_id=gym.id).first()
    if not member:
        return jsonify({
            'success': False, 
            'message': 'Member not found',
            'hindi_message': 'सदस्य नहीं मिला'
        })
    
    # Check if attendance already marked for today
    today = datetime.utcnow().date()
    existing = Attendance.query.filter_by(
        member_id=member_id, 
        date=today,
        gym_id=gym.id
    ).first()
    
    if existing:
        return jsonify({
            'success': False, 
            'message': f'Attendance already marked for {member.full_name} today',
            'hindi_message': f'{member.full_name} की आज की उपस्थिति पहले ही चिह्नित कर दी गई है'
        })
    
    # Mark attendance
    attendance = Attendance(
        member_id=member_id,
        date=today,
        gym_id=gym.id,
        method='qr'
    )
    
    db.session.add(attendance)
    db.session.commit()
    
    # Send email notification
    send_attendance_notification(attendance)
    
    return jsonify({
        'success': True, 
        'message': f'Attendance marked successfully for {member.full_name}',
        'hindi_message': f'{member.full_name} की उपस्थिति सफलतापूर्वक चिह्नित की गई',
        'member_name': member.full_name
    })
