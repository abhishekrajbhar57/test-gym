from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from models import Gym, Member, Payment, Attendance
from datetime import datetime, timedelta
from app import db

gym_bp = Blueprint('gym', __name__)

def gym_manager_required(f):
    """Decorator to check if user is a gym manager"""
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'gym_manager':
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@gym_bp.route('/dashboard')
@login_required
@gym_manager_required
def dashboard():
    # Get the gym for the current manager
    gym = Gym.query.filter_by(user_id=current_user.id).first()
    
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    # Statistics for dashboard
    total_members = Member.query.filter_by(gym_id=gym.id).count()
    
    # Active members (membership hasn't expired)
    today = datetime.utcnow().date()
    active_members = Member.query.filter_by(gym_id=gym.id).filter(Member.membership_end >= today).count()
    
    # Attendance for today
    today_attendance = Attendance.query.filter_by(gym_id=gym.id, date=today).count()
    
    # Payments in last 30 days
    thirty_days_ago = today - timedelta(days=30)
    recent_payments = Payment.query.filter_by(gym_id=gym.id).filter(Payment.date >= thirty_days_ago).all()
    total_revenue = sum(float(payment.amount) for payment in recent_payments)
    
    # Members with expiring memberships in next 7 days
    next_week = today + timedelta(days=7)
    expiring_members = Member.query.filter_by(gym_id=gym.id).filter(
        Member.membership_end >= today,
        Member.membership_end <= next_week
    ).all()
    
    # Recent attendance (last 5 days)
    five_days_ago = today - timedelta(days=5)
    attendance_data = []
    
    for i in range(6):
        day = five_days_ago + timedelta(days=i)
        count = Attendance.query.filter_by(gym_id=gym.id, date=day).count()
        attendance_data.append({
            'date': day.strftime('%Y-%m-%d'),
            'count': count
        })
    
    return render_template(
        'gym/dashboard.html', 
        gym=gym, 
        total_members=total_members, 
        active_members=active_members, 
        today_attendance=today_attendance, 
        total_revenue=total_revenue, 
        expiring_members=expiring_members,
        attendance_data=attendance_data
    )
