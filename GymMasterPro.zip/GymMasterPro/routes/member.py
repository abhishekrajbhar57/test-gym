from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required, current_user
from models import Gym, Member
from forms import MemberForm
from app import db
from utils import generate_qr_code, is_membership_expired
from datetime import datetime
import base64

member_bp = Blueprint('member', __name__)

def get_current_gym():
    """Helper function to get the current gym for the logged-in manager"""
    return Gym.query.filter_by(user_id=current_user.id).first()

@member_bp.route('/list')
@login_required
def list_members():
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    members = Member.query.filter_by(gym_id=gym.id).all()
    
    # Check if any member's membership has expired
    today = datetime.utcnow().date()
    for member in members:
        member.is_expired = member.membership_end < today
    
    return render_template('gym/members.html', members=members, gym=gym, is_expired=is_membership_expired)

@member_bp.route('/add', methods=['GET', 'POST'])
@login_required
def add_member():
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    form = MemberForm()
    
    if form.validate_on_submit():
        # Create new member
        member = Member(
            full_name=form.full_name.data,
            email=form.email.data,
            phone=form.phone.data,
            gender=form.gender.data,
            dob=form.dob.data,
            membership_start=form.membership_start.data,
            membership_end=form.membership_end.data,
            gym_id=gym.id
        )
        
        # Handle photo if uploaded (store as base64)
        if 'photo' in request.files and request.files['photo'].filename:
            photo_file = request.files['photo']
            photo_data = photo_file.read()
            photo_base64 = base64.b64encode(photo_data).decode('utf-8')
            member.photo_url = f"data:{photo_file.content_type};base64,{photo_base64}"
        
        db.session.add(member)
        db.session.commit()
        
        flash('Member added successfully!', 'success')
        flash('सदस्य सफलतापूर्वक जोड़ा गया!', 'success')
        return redirect(url_for('member.list_members'))
    
    return render_template('gym/member_form.html', form=form, gym=gym, title='Add New Member')

@member_bp.route('/edit/<int:member_id>', methods=['GET', 'POST'])
@login_required
def edit_member(member_id):
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    member = Member.query.get_or_404(member_id)
    
    # Ensure member belongs to this gym
    if member.gym_id != gym.id:
        flash('You do not have permission to edit this member.', 'danger')
        return redirect(url_for('member.list_members'))
    
    form = MemberForm(obj=member)
    
    if form.validate_on_submit():
        # Update member
        member.full_name = form.full_name.data
        member.email = form.email.data
        member.phone = form.phone.data
        member.gender = form.gender.data
        member.dob = form.dob.data
        member.membership_start = form.membership_start.data
        member.membership_end = form.membership_end.data
        
        # Handle photo if uploaded (store as base64)
        if 'photo' in request.files and request.files['photo'].filename:
            photo_file = request.files['photo']
            photo_data = photo_file.read()
            photo_base64 = base64.b64encode(photo_data).decode('utf-8')
            member.photo_url = f"data:{photo_file.content_type};base64,{photo_base64}"
        
        db.session.commit()
        
        flash('Member updated successfully!', 'success')
        flash('सदस्य सफलतापूर्वक अपडेट किया गया!', 'success')
        return redirect(url_for('member.list_members'))
    
    return render_template('gym/member_form.html', form=form, gym=gym, title='Edit Member', member=member)

@member_bp.route('/delete/<int:member_id>')
@login_required
def delete_member(member_id):
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    member = Member.query.get_or_404(member_id)
    
    # Ensure member belongs to this gym
    if member.gym_id != gym.id:
        flash('You do not have permission to delete this member.', 'danger')
        return redirect(url_for('member.list_members'))
    
    db.session.delete(member)
    db.session.commit()
    
    flash('Member deleted successfully!', 'success')
    flash('सदस्य सफलतापूर्वक हटा दिया गया!', 'success')
    return redirect(url_for('member.list_members'))

@member_bp.route('/view/<int:member_id>')
@login_required
def view_member(member_id):
    gym = get_current_gym()
    if not gym:
        flash('No gym found for your account. Please contact admin.', 'danger')
        return redirect(url_for('auth.logout'))
    
    member = Member.query.get_or_404(member_id)
    
    # Ensure member belongs to this gym
    if member.gym_id != gym.id:
        flash('You do not have permission to view this member.', 'danger')
        return redirect(url_for('member.list_members'))
    
    # Generate QR code for member
    qr_code = generate_qr_code(gym.id, member.id)
    
    # Get member's attendance and payment history
    from models import Attendance, Payment
    attendances = Attendance.query.filter_by(member_id=member.id).order_by(Attendance.date.desc()).limit(10).all()
    payments = Payment.query.filter_by(member_id=member.id).order_by(Payment.date.desc()).limit(5).all()
    
    return render_template(
        'gym/member_detail.html', 
        member=member, 
        gym=gym, 
        qr_code=qr_code, 
        attendances=attendances, 
        payments=payments, 
        is_expired=is_membership_expired(member)
    )
