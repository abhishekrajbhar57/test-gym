/**
 * PDF Invoice Generator for Gym Management System
 * Using jsPDF library
 */
document.addEventListener('DOMContentLoaded', function() {
    // Find all invoice buttons
    const invoiceButtons = document.querySelectorAll('.generate-invoice');
    
    if (invoiceButtons.length > 0) {
        invoiceButtons.forEach(button => {
            button.addEventListener('click', function() {
                const paymentId = this.getAttribute('data-payment-id');
                
                // Fetch payment details
                fetch(`/payment/get_invoice_data/${paymentId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            generateInvoice(data.data);
                        } else {
                            alert('Error: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while generating the invoice');
                    });
            });
        });
    }
    
    /**
     * Generate PDF invoice using jsPDF
     */
    function generateInvoice(data) {
        // Create new jsPDF instance
        const doc = new jspdf.jsPDF();
        
        // Set font styles
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(20);
        
        // Add gym logo/name at the top
        doc.text(data.gym_name, 105, 20, { align: 'center' });
        
        // Add title
        doc.setFontSize(16);
        doc.text('PAYMENT RECEIPT', 105, 30, { align: 'center' });
        
        // Add horizontal line
        doc.setLineWidth(0.5);
        doc.line(20, 35, 190, 35);
        
        // Add receipt details
        doc.setFontSize(12);
        
        // Left column
        doc.text('Receipt No:', 20, 50);
        doc.text('Date:', 20, 60);
        doc.text('Payment Mode:', 20, 70);
        
        // Right column (values)
        doc.text(`${data.payment_id}`, 80, 50);
        doc.text(`${data.date}`, 80, 60);
        doc.text(`${data.payment_mode}`, 80, 70);
        
        // Add horizontal line
        doc.line(20, 80, 190, 80);
        
        // Member details
        doc.text('Member Details', 20, 95);
        doc.text(`Name: ${data.member_name}`, 20, 105);
        
        // Payment details
        doc.text('Payment Details', 20, 120);
        
        // Table header
        doc.setFont('helvetica', 'bold');
        doc.text('Description', 20, 130);
        doc.text('Amount', 150, 130);
        
        // Table content
        doc.setFont('helvetica', 'normal');
        doc.text('Gym Membership Fee', 20, 140);
        doc.text(`₹ ${data.amount}`, 150, 140);
        
        // Add horizontal line
        doc.line(20, 150, 190, 150);
        
        // Total
        doc.setFont('helvetica', 'bold');
        doc.text('Total', 120, 160);
        doc.text(`₹ ${data.amount}`, 150, 160);
        
        // Footer
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text('Thank you for your payment!', 105, 180, { align: 'center' });
        doc.text(`This is a computer-generated receipt and does not require a signature.`, 105, 185, { align: 'center' });
        
        // Generate the PDF and download
        const filename = `invoice_${data.member_name.replace(/\s+/g, '_')}_${data.date}.pdf`;
        doc.save(filename);
    }
});
