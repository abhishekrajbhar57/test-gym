/**
 * Attendance management scripts for Gym Management System
 */
document.addEventListener('DOMContentLoaded', function() {
    // Mark attendance button handler
    const attendanceButtons = document.querySelectorAll('.mark-attendance');
    
    if (attendanceButtons.length > 0) {
        attendanceButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                const memberId = this.getAttribute('data-member-id');
                const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
                
                // Create form data
                const formData = new FormData();
                formData.append('member_id', memberId);
                formData.append('csrf_token', csrfToken);
                
                // Send attendance request
                fetch('/attendance/mark', {
                    method: 'POST',
                    headers: {
                        'X-CSRFToken': csrfToken
                    },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Show success message
                        showAlert(true, data.message, data.hindi_message);
                        
                        // Disable the button to prevent duplicate attendance
                        this.disabled = true;
                        this.textContent = 'Present';
                        this.classList.remove('btn-primary');
                        this.classList.add('btn-success');
                        
                        // Update attendance count if present on the page
                        const attendanceCountEl = document.getElementById('today-attendance-count');
                        if (attendanceCountEl) {
                            const count = parseInt(attendanceCountEl.textContent) + 1;
                            attendanceCountEl.textContent = count;
                        }
                    } else {
                        // Show error message
                        showAlert(false, data.message, data.hindi_message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showAlert(false, 'An error occurred while marking attendance', 'उपस्थिति चिह्नित करते समय एक त्रुटि हुई');
                });
            });
        });
    }
    
    // Date filter for attendance
    const attendanceDateFilter = document.getElementById('attendance-date-filter');
    if (attendanceDateFilter) {
        attendanceDateFilter.addEventListener('change', function() {
            const selectedDate = this.value;
            window.location.href = `/attendance/list?date=${selectedDate}`;
        });
    }
    
    // Show alert function (reusable)
    function showAlert(isSuccess, message, hindiMessage) {
        // Get or create alert containers
        let alertContainer = document.getElementById('alert-container');
        if (!alertContainer) {
            alertContainer = document.createElement('div');
            alertContainer.id = 'alert-container';
            alertContainer.className = 'mt-3';
            
            // Find a good place to insert the alert
            const contentArea = document.querySelector('.content-area') || document.querySelector('main') || document.body;
            contentArea.insertBefore(alertContainer, contentArea.firstChild);
        }
        
        // Create alert
        const alertDiv = document.createElement('div');
        alertDiv.className = isSuccess ? 'alert alert-success' : 'alert alert-danger';
        alertDiv.role = 'alert';
        
        // Add message
        alertDiv.textContent = message;
        
        // Add Hindi message if available
        if (hindiMessage) {
            const hindiSpan = document.createElement('span');
            hindiSpan.className = 'alert-hindi d-block';
            hindiSpan.textContent = hindiMessage;
            alertDiv.appendChild(hindiSpan);
        }
        
        // Add close button
        const closeButton = document.createElement('button');
        closeButton.type = 'button';
        closeButton.className = 'btn-close';
        closeButton.setAttribute('data-bs-dismiss', 'alert');
        closeButton.setAttribute('aria-label', 'Close');
        alertDiv.appendChild(closeButton);
        
        // Clear previous alerts
        alertContainer.innerHTML = '';
        
        // Add the alert to the container
        alertContainer.appendChild(alertDiv);
        
        // Auto hide after 5 seconds
        setTimeout(() => {
            alertDiv.classList.add('fade');
            setTimeout(() => {
                if (alertContainer.contains(alertDiv)) {
                    alertContainer.removeChild(alertDiv);
                }
            }, 500);
        }, 5000);
    }
});
