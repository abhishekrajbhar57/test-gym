/**
 * QR Code Scanner for Gym Attendance
 */
document.addEventListener('DOMContentLoaded', function() {
    const qrScannerContainer = document.getElementById('reader');
    
    if (qrScannerContainer) {
        // Alert containers
        const successAlert = document.getElementById('success-alert');
        const errorAlert = document.getElementById('error-alert');
        const successHindiAlert = document.getElementById('success-hindi-alert');
        const errorHindiAlert = document.getElementById('error-hindi-alert');
        
        // Show alert function
        function showAlert(isSuccess, message, hindiMessage) {
            if (isSuccess) {
                successAlert.textContent = message;
                successAlert.classList.remove('d-none');
                
                if (hindiMessage) {
                    successHindiAlert.textContent = hindiMessage;
                    successHindiAlert.classList.remove('d-none');
                }
                
                errorAlert.classList.add('d-none');
                errorHindiAlert.classList.add('d-none');
            } else {
                errorAlert.textContent = message;
                errorAlert.classList.remove('d-none');
                
                if (hindiMessage) {
                    errorHindiAlert.textContent = hindiMessage;
                    errorHindiAlert.classList.remove('d-none');
                }
                
                successAlert.classList.add('d-none');
                successHindiAlert.classList.add('d-none');
            }
            
            // Auto hide after 5 seconds
            setTimeout(() => {
                successAlert.classList.add('d-none');
                errorAlert.classList.add('d-none');
                successHindiAlert.classList.add('d-none');
                errorHindiAlert.classList.add('d-none');
            }, 5000);
        }
        
        // Process QR code data
        function onScanSuccess(decodedText) {
            // Play a beep sound
            const beep = new Audio("data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU..."); // Base64 truncated for brevity
            beep.play();
            
            // Get CSRF token from meta tag
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            
            // Process the QR code data
            fetch('/attendance/process_qr', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': csrfToken
                },
                body: JSON.stringify({ qrData: decodedText })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert(true, data.message, data.hindi_message);
                    
                    // Update attendance list if exists
                    const attendanceList = document.getElementById('attendance-list');
                    if (attendanceList) {
                        const newRow = document.createElement('tr');
                        newRow.innerHTML = `
                            <td>${data.member_name}</td>
                            <td>${new Date().toLocaleTimeString()}</td>
                            <td>QR Code</td>
                        `;
                        attendanceList.appendChild(newRow);
                    }
                } else {
                    showAlert(false, data.message, data.hindi_message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert(false, 'An error occurred while processing the QR code', 'QR कोड को संसाधित करते समय एक त्रुटि हुई');
            });
        }
        
        // Initialize HTML5 QR Scanner
        const html5QrCode = new Html5Qrcode("reader");
        
        // Configuration
        const config = { fps: 10, qrbox: 250 };
        
        // Start scanner with camera
        html5QrCode.start(
            { facingMode: "environment" }, 
            config, 
            onScanSuccess
        ).catch(err => {
            console.error('Error starting QR scanner:', err);
            showAlert(false, 'Could not start camera. Please check permissions.', 'कैमरा शुरू नहीं कर सका। कृपया अनुमतियों की जांच करें।');
        });
        
        // Add stop button functionality
        const stopButton = document.getElementById('stop-scanner');
        if (stopButton) {
            stopButton.addEventListener('click', () => {
                html5QrCode.stop().then(() => {
                    console.log('QR Scanner stopped');
                    window.location.href = '/attendance/list';
                }).catch(err => {
                    console.error('Error stopping QR scanner:', err);
                });
            });
        }
    }
});
