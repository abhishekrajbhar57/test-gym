import os
import csv
import qrcode
import smtplib
import json
from io import BytesIO, StringIO
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime, timedelta
from flask import current_app, url_for
from models import Member, Payment, Attendance, EmailSettings
from app import db

def generate_qr_code(gym_id, member_id):
    """Generate QR code for member attendance"""
    data = f"{gym_id}:{member_id}"
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    buffer = BytesIO()
    img.save(buffer)
    
    # Convert to base64 for embedding in HTML
    import base64
    buffer.seek(0)
    qr_base64 = base64.b64encode(buffer.getvalue()).decode()
    return f"data:image/png;base64,{qr_base64}"

def export_gym_members(gym_id):
    """Export gym members to CSV"""
    members = Member.query.filter_by(gym_id=gym_id).all()
    
    # Use BytesIO instead of StringIO for binary mode
    output = BytesIO()
    
    # Convert to bytes for binary file handling
    csv_data = StringIO()
    writer = csv.writer(csv_data)
    
    # Write header
    writer.writerow(['Full Name', 'Email', 'Phone', 'Gender', 'Date of Birth', 'Membership Start', 'Membership End'])
    
    # Write member data
    for member in members:
        writer.writerow([
            member.full_name,
            member.email or '',
            member.phone,
            member.gender,
            member.dob.strftime('%Y-%m-%d'),
            member.membership_start.strftime('%Y-%m-%d'),
            member.membership_end.strftime('%Y-%m-%d')
        ])
    
    # Get string data and encode to bytes
    output.write(csv_data.getvalue().encode('utf-8'))
    output.seek(0)
    return output

def check_expiring_memberships():
    """Check for memberships expiring in 3 days"""
    expiry_date = datetime.utcnow().date() + timedelta(days=3)
    expiring_members = Member.query.filter_by(membership_end=expiry_date).all()
    
    for member in expiring_members:
        # Send email notification
        email_settings = EmailSettings.query.filter_by(gym_id=member.gym_id).first()
        if email_settings and email_settings.enabled and member.email:
            subject = email_settings.membership_expiry_subject
            templates = json.loads(email_settings.membership_expiry_template)
            
            # English by default
            template = templates.get('en')
            
            # Replace placeholders
            content = template.replace('{{member_name}}', member.full_name)
            content = content.replace('{{expiry_date}}', member.membership_end.strftime('%Y-%m-%d'))
            content = content.replace('{{gym_name}}', member.gym.name)
            
            send_email(member.email, subject, content)

def send_payment_notification(payment):
    """Send email notification for successful payment"""
    member = Member.query.get(payment.member_id)
    if not member or not member.email:
        return
    
    email_settings = EmailSettings.query.filter_by(gym_id=payment.gym_id).first()
    if not email_settings or not email_settings.enabled:
        return
    
    subject = email_settings.payment_success_subject
    templates = json.loads(email_settings.payment_success_template)
    
    # English by default
    template = templates.get('en')
    
    # Replace placeholders
    content = template.replace('{{member_name}}', member.full_name)
    content = content.replace('{{amount}}', payment.amount)
    content = content.replace('{{date}}', payment.date.strftime('%Y-%m-%d'))
    content = content.replace('{{gym_name}}', member.gym.name)
    
    send_email(member.email, subject, content)

def send_attendance_notification(attendance):
    """Send email notification for marked attendance"""
    member = Member.query.get(attendance.member_id)
    if not member or not member.email:
        return
    
    email_settings = EmailSettings.query.filter_by(gym_id=attendance.gym_id).first()
    if not email_settings or not email_settings.enabled:
        return
    
    subject = email_settings.attendance_marked_subject
    templates = json.loads(email_settings.attendance_marked_template)
    
    # English by default
    template = templates.get('en')
    
    # Replace placeholders
    content = template.replace('{{member_name}}', member.full_name)
    content = content.replace('{{date}}', attendance.date.strftime('%Y-%m-%d'))
    content = content.replace('{{gym_name}}', member.gym.name)
    
    send_email(member.email, subject, content)

def send_email(to_email, subject, body):
    """Send an email using Brevo SMTP relay"""
    try:
        # Check if we have SENDGRID API key
        if os.environ.get('SENDGRID_API_KEY'):
            # Use SendGrid if API key is available
            from sendgrid import SendGridAPIClient
            from sendgrid.helpers.mail import Mail, Email, To, Content

            message = Mail(
                from_email=Email("gym.management@example.com"),
                to_emails=To(to_email),
                subject=subject,
                html_content=Content("text/html", body)
            )

            sg = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
            sg.send(message)
            current_app.logger.info(f"Email sent to {to_email} via SendGrid")
            return True
        else:
            # Fallback to Brevo SMTP relay
            smtp_server = "smtp-relay.brevo.com"
            smtp_port = 587
            smtp_username = "admin@gym.com"  # Can be any email address for Brevo
            # Try to get from environment or use default
            smtp_password = os.environ.get('BREVO_API_KEY', "N59UxWJnh6R4M12T")
            sender_email = "gym.management@example.com"
            
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = to_email
            msg['Subject'] = subject
            
            msg.attach(MIMEText(body, 'html'))  # Support HTML formatting
            
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(smtp_username, smtp_password)
            text = msg.as_string()
            server.sendmail(sender_email, to_email, text)
            server.quit()
            
            current_app.logger.info(f"Email sent to {to_email} via Brevo")
            return True
    except Exception as e:
        current_app.logger.error(f"Failed to send email: {str(e)}")
        # Continue without failing if we can't send email
        return False

def is_membership_expired(member):
    """Check if member's membership has expired"""
    return member.membership_end < datetime.utcnow().date()

def create_default_email_settings(gym_id):
    """Create default email settings for a new gym"""
    existing = EmailSettings.query.filter_by(gym_id=gym_id).first()
    if not existing:
        default_settings = EmailSettings(gym_id=gym_id)
        db.session.add(default_settings)
        db.session.commit()
        return default_settings
    return existing
