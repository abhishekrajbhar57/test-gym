from datetime import datetime
from flask_login import UserMixin
from app import db
import json

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    role = db.Column(db.String(20), nullable=False, default='gym_manager')  # admin or gym_manager
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    gym = db.relationship('Gym', backref='manager', uselist=False, cascade="all, delete-orphan")
    
    def __repr__(self):
        return f'<User {self.username}>'

class Gym(db.Model):
    __tablename__ = 'gyms'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    members = db.relationship('Member', backref='gym', cascade="all, delete-orphan")
    payments = db.relationship('Payment', backref='gym', cascade="all, delete-orphan")
    attendances = db.relationship('Attendance', backref='gym', cascade="all, delete-orphan")
    
    def __repr__(self):
        return f'<Gym {self.name}>'

class Member(db.Model):
    __tablename__ = 'members'
    
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120))
    phone = db.Column(db.String(20), nullable=False)
    gender = db.Column(db.String(10), nullable=False)
    dob = db.Column(db.Date, nullable=False)
    membership_start = db.Column(db.Date, nullable=False)
    membership_end = db.Column(db.Date, nullable=False)
    photo_url = db.Column(db.String(256))
    gym_id = db.Column(db.Integer, db.ForeignKey('gyms.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    attendances = db.relationship('Attendance', backref='member', cascade="all, delete-orphan")
    payments = db.relationship('Payment', backref='member', cascade="all, delete-orphan")
    
    def __repr__(self):
        return f'<Member {self.full_name}>'

class Attendance(db.Model):
    __tablename__ = 'attendances'
    
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.Integer, db.ForeignKey('members.id'), nullable=False)
    date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date)
    check_in_time = db.Column(db.DateTime, default=datetime.utcnow)
    method = db.Column(db.String(20), default='manual')  # manual or qr
    gym_id = db.Column(db.Integer, db.ForeignKey('gyms.id'), nullable=False)
    
    def __repr__(self):
        return f'<Attendance {self.member_id} on {self.date}>'

class Payment(db.Model):
    __tablename__ = 'payments'
    
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.Integer, db.ForeignKey('members.id'), nullable=False)
    amount = db.Column(db.String(20), nullable=False)  # String type as per requirements
    date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date)
    payment_mode = db.Column(db.String(10), nullable=False)  # Cash/UPI/Card
    gym_id = db.Column(db.Integer, db.ForeignKey('gyms.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Payment {self.id} for {self.member_id}>'

class EmailSettings(db.Model):
    __tablename__ = 'email_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    gym_id = db.Column(db.Integer, db.ForeignKey('gyms.id'), nullable=False)
    enabled = db.Column(db.Boolean, default=True)
    membership_expiry_template = db.Column(db.Text, nullable=False)
    payment_success_template = db.Column(db.Text, nullable=False)
    attendance_marked_template = db.Column(db.Text, nullable=False)
    membership_expiry_subject = db.Column(db.String(256), nullable=False)
    payment_success_subject = db.Column(db.String(256), nullable=False)
    attendance_marked_subject = db.Column(db.String(256), nullable=False)
    
    def __init__(self, gym_id):
        self.gym_id = gym_id
        self.enabled = True
        
        # Default templates
        self.membership_expiry_subject = "Membership Expiry Notice"
        self.membership_expiry_template = json.dumps({
            "en": "Dear {{member_name}},\n\nYour gym membership is expiring in 3 days on {{expiry_date}}. Please renew it soon.\n\nRegards,\n{{gym_name}}",
            "hi": "प्रिय {{member_name}},\n\nआपकी जिम सदस्यता {{expiry_date}} को 3 दिनों में समाप्त हो रही है। कृपया इसे जल्द ही नवीनीकृत करें।\n\nसादर,\n{{gym_name}}"
        })
        
        self.payment_success_subject = "Payment Confirmation"
        self.payment_success_template = json.dumps({
            "en": "Dear {{member_name}},\n\nYour payment of {{amount}} has been received successfully on {{date}}.\n\nRegards,\n{{gym_name}}",
            "hi": "प्रिय {{member_name}},\n\nआपका {{amount}} का भुगतान {{date}} को सफलतापूर्वक प्राप्त हो गया है।\n\nसादर,\n{{gym_name}}"
        })
        
        self.attendance_marked_subject = "Attendance Confirmation"
        self.attendance_marked_template = json.dumps({
            "en": "Dear {{member_name}},\n\nYour attendance has been marked for {{date}}.\n\nRegards,\n{{gym_name}}",
            "hi": "प्रिय {{member_name}},\n\nआपकी उपस्थिति {{date}} के लिए चिह्नित कर दी गई है।\n\nसादर,\n{{gym_name}}"
        })
