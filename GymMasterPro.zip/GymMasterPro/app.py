import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from datetime import datetime
from flask_wtf.csrf import CSRFProtect

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key_for_development")

# Configure SQLite database
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///gym_management.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize SQLAlchemy
db = SQLAlchemy(app)

# Initialize CSRF Protection
csrf = CSRFProtect(app)

# Initialize LoginManager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "auth.login"
login_manager.login_message = "Please log in to access this page."

# Import models after initializing db to avoid circular imports
from models import User

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Register blueprints
from routes.auth import auth_bp
from routes.admin import admin_bp
from routes.gym import gym_bp
from routes.member import member_bp
from routes.attendance import attendance_bp
from routes.payment import payment_bp
from routes.email import email_bp

app.register_blueprint(auth_bp)
app.register_blueprint(admin_bp, url_prefix='/admin')
app.register_blueprint(gym_bp, url_prefix='/gym')
app.register_blueprint(member_bp, url_prefix='/member')
app.register_blueprint(attendance_bp, url_prefix='/attendance')
app.register_blueprint(payment_bp, url_prefix='/payment')
app.register_blueprint(email_bp, url_prefix='/email')

# Create database tables
with app.app_context():
    db.create_all()
    
    # Create admin user if not exists
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        from werkzeug.security import generate_password_hash
        admin = User(
            username='admin',
            password_hash=generate_password_hash('admin123'),
            email='admin@gym.com',
            role='admin',
            is_active=True
        )
        db.session.add(admin)
        db.session.commit()
        logging.info("Admin user created.")

@app.context_processor
def inject_now():
    return {'now': datetime.utcnow()}
