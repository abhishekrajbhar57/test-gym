from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, DateField, FileField, HiddenField, BooleanField, TextAreaField
from wtforms.validators import DataRequired, Email, Optional, Length, ValidationError
from datetime import date

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class GymForm(FlaskForm):
    name = StringField('Gym Name', validators=[DataRequired()])
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=25)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    submit = SubmitField('Create Gym')

class MemberForm(FlaskForm):
    full_name = StringField('Full Name', validators=[DataRequired()])
    email = StringField('Email', validators=[Optional(), Email()])
    phone = StringField('Phone Number', validators=[DataRequired()])
    gender = SelectField('Gender', choices=[('male', 'Male'), ('female', 'Female'), ('other', 'Other')], validators=[DataRequired()])
    dob = DateField('Date of Birth', validators=[DataRequired()], format='%Y-%m-%d')
    membership_start = DateField('Membership Start Date', validators=[DataRequired()], format='%Y-%m-%d', default=date.today)
    membership_end = DateField('Membership End Date', validators=[DataRequired()], format='%Y-%m-%d')
    photo = FileField('Photo (Optional)')
    submit = SubmitField('Save Member')

    def validate_membership_end(self, field):
        if field.data < self.membership_start.data:
            raise ValidationError("End date cannot be earlier than start date")

class AttendanceForm(FlaskForm):
    member_id = HiddenField('Member ID', validators=[DataRequired()])
    submit = SubmitField('Mark Attendance')

class PaymentForm(FlaskForm):
    member_id = SelectField('Member', validators=[DataRequired()], coerce=int)
    amount = StringField('Amount', validators=[DataRequired()])
    date = DateField('Payment Date', validators=[DataRequired()], format='%Y-%m-%d', default=date.today)
    payment_mode = SelectField('Payment Mode', choices=[('Cash', 'Cash'), ('UPI', 'UPI'), ('Card', 'Card')], validators=[DataRequired()])
    submit = SubmitField('Record Payment')

class EmailSettingsForm(FlaskForm):
    enabled = BooleanField('Enable Email Notifications')
    
    membership_expiry_subject = StringField('Membership Expiry Subject', validators=[DataRequired()])
    membership_expiry_template_en = TextAreaField('Membership Expiry Template (English)', validators=[DataRequired()])
    membership_expiry_template_hi = TextAreaField('Membership Expiry Template (Hindi)', validators=[DataRequired()])
    
    payment_success_subject = StringField('Payment Success Subject', validators=[DataRequired()])
    payment_success_template_en = TextAreaField('Payment Success Template (English)', validators=[DataRequired()])
    payment_success_template_hi = TextAreaField('Payment Success Template (Hindi)', validators=[DataRequired()])
    
    attendance_marked_subject = StringField('Attendance Marked Subject', validators=[DataRequired()])
    attendance_marked_template_en = TextAreaField('Attendance Marked Template (English)', validators=[DataRequired()])
    attendance_marked_template_hi = TextAreaField('Attendance Marked Template (Hindi)', validators=[DataRequired()])
    
    submit = SubmitField('Save Settings')
